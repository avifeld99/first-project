package be.intecbrussel2;

public class FirstString {

    public static void main(String[] args) {

        String name = "Avi";
        System.out.println(name.toUpperCase());

        System.out.println(name.toLowerCase());

        int lengthstring = name.length();
        System.out.println(lengthstring);

    }
}
