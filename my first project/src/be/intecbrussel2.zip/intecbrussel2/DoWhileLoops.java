package be.intecbrussel2;

public class DoWhileLoops {

    public static void main(String[]args) {


        int number = 0;
        int sum = 0;

        do {
            sum += number;
            number++;
        }
        while(number < 10);

        System.out.println("the sum is: " + sum);

















    }
}
